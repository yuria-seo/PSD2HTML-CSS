/*! 첫번째 레이어 보임/숨김 토글 스크립트, 2013 @ yamoo9.net */
(function(d){var t=d.layers[0];t.visible=!t.visible;})(activeDocument);